package zn.qyh.springboot01quickcreate.service;

/**
 * @author 曲逸涵
 * @date 2020/2/13 3:51
 * @Email:2628908921@qq.com
 */
public class HelloService {
}
