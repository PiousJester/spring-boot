package zn.jester.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataMybatisApplicationTests {

    @Test
    void contextLoads() {
    }

}
