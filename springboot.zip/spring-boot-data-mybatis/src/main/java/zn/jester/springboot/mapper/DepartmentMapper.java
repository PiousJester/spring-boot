package zn.jester.springboot.mapper;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import zn.jester.springboot.bean.Department;

/**
 * @author 曲逸涵
 * @date 2020/3/31 16:33
 * @Email:2628908921@qq.com
 */
@Mapper
public interface DepartmentMapper {
    @Select("select * FROM department where id=#{id}")
    public Department getDeptById(Integer id);
    @Delete("delete * FROM department where id=#{id}")
    public int deleteDeptById(Integer id);
    @Options(useGeneratedKeys = true,keyProperty = "id")
    @Insert("insert into department(departmentName) values(#{departmentName})")
    public int insertDept(Department department);
    @Update("update department set departmentName=#{departmentName} where id=#{id}")
    public int updateDept(Department department);
}
