package zn.jester.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
