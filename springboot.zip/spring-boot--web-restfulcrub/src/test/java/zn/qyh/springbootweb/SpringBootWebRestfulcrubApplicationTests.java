package zn.qyh.springbootweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebRestfulcrubApplicationTests {

    @Test
    void contextLoads() {
    }

}
