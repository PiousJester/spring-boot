package zn.qyh.springbootweb.component;


import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.WebRequest;

import java.util.Map;

/**
 * @author 曲逸涵
 * @date 2020/3/24 12:11
 * @Email:2628908921@qq.com
 */
//给容器中加入自己的ErrorAttributes
@Component
public class MyErrorAttributes extends DefaultErrorAttributes {
    public MyErrorAttributes() {
        super(true);
    }

    @Override
    public Map<String, Object> getErrorAttributes(WebRequest webRequest, boolean includeStackTrace) {
        Map<String,Object> map=super.getErrorAttributes(webRequest, includeStackTrace);
        map.put("company","Test_");
        Map<String,Object> ext = (Map<String,Object>)webRequest.getAttribute("ext", 0);
        map.put("ext",ext);
        return map;
    }
}
