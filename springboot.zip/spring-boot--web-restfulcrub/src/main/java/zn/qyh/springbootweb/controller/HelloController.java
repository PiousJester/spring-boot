package zn.qyh.springbootweb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import zn.qyh.springbootweb.exception.UserNotExist;

import java.util.Arrays;
import java.util.Map;

/**
 * @author 曲逸涵
 * @date 2020/3/3 18:54
 * @Email:2628908921@qq.com
 */
@Controller
public class HelloController {
//    @RequestMapping({"/","login.html"})
//    public String login(){
//        return "login";
//    }
    @ResponseBody
    @RequestMapping("/hello")
    public String hello(@RequestParam("user") String user){
        if(user.equals("aaa")){
            throw new UserNotExist();
        }
        return "Hello World";
    }
    @RequestMapping("/success")
    public String success(Map<String,Object> map){
        map.put("hello","<h1>你好</h1>");
        map.put("user", Arrays.asList("zhangsan","lisi","wangwu"));
        return "success";
    }
}
