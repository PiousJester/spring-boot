package zn.qyh.springbootweb.exception;

/**
 * @author 曲逸涵
 * @date 2020/3/23 18:10
 * @Email:2628908921@qq.com
 */
public class UserNotExist extends RuntimeException {
    public UserNotExist() {
          super("用户不存在");
    }
}
