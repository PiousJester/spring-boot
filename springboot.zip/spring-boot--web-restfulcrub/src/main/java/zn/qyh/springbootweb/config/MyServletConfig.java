package zn.qyh.springbootweb.config;

import org.springframework.boot.autoconfigure.web.embedded.EmbeddedWebServerFactoryCustomizerAutoConfiguration;
import org.springframework.boot.autoconfigure.web.embedded.TomcatWebServerFactoryCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.WebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import zn.qyh.springbootweb.filter.MyFilter;
import zn.qyh.springbootweb.listener.MyListener;
import zn.qyh.springbootweb.servlet.MyServlet;

import java.util.Arrays;

/**
 * @author 曲逸涵
 * @date 2020/3/24 20:11
 * @Email:2628908921@qq.com
 */
@Configuration
public class MyServletConfig {
    //注册三大组件
    @Bean
    public ServletRegistrationBean myServlet(){
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new MyServlet(),"/myServlet");
        return servletRegistrationBean;
    }
    @Bean
    public FilterRegistrationBean myFilter(){
        FilterRegistrationBean <MyFilter> FilterRegistrationBean=new <MyFilter> FilterRegistrationBean(new MyFilter());
        FilterRegistrationBean.setUrlPatterns(Arrays.asList("/hello","/myServlet"));
        return FilterRegistrationBean;
    }
    @Bean
    public ServletListenerRegistrationBean servletListenerRegistrationBean(){
          ServletListenerRegistrationBean <MyListener> servletListenerRegistrationBean=new  <MyListener> ServletListenerRegistrationBean(new MyListener());
          return servletListenerRegistrationBean;
    }
    //配置嵌入式的Servlet容器
  @Bean
 public WebServerFactoryCustomizer <ConfigurableWebServerFactory> WebServerFactoryCustomizer (){
        return factory -> {
            factory.setPort(80);
        };
   }
}
