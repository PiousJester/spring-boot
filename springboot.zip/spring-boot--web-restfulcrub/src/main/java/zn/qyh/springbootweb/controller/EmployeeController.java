package zn.qyh.springbootweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import zn.qyh.springbootweb.dao.DepartmentDao;
import zn.qyh.springbootweb.dao.EmployeeDao;
import zn.qyh.springbootweb.entities.Department;
import zn.qyh.springbootweb.entities.Employee;

import java.util.Collection;

/**
 * @author 曲逸涵
 * @date 2020/3/18 17:46
 * @Email:2628908921@qq.com
 */
@Controller
public class EmployeeController {
    @Autowired
    EmployeeDao employeeDao;
    @Autowired
    DepartmentDao departmentDao;
    //查询所有员工列表，返回员工列表页面
    @GetMapping("/emps")
    public String list(Model model){
        Collection<Employee> employees = employeeDao.getAll();
        //放在请求域中
        model.addAttribute("emps",employees);
       return "emp/list";
    }
    //来到员工的添加界面
    @GetMapping("/emp")
    public String toAddPage(Model model) {
      //来添加页面,查出所有的部门在页面显示
        Collection<Department> departments=departmentDao.getDepartments();
        model.addAttribute("depts",departments);
        return "emp/add";
    }
    //员工添加
    @PostMapping("/emp")
    public String addEmp(Employee employee){
        //来到员工列表页面
        employeeDao.save(employee);
        return "redirect:/emps";
    }
    @GetMapping("/emp/{id}")
    public String toEditPage(@PathVariable("id")Integer id,Model model){
        Employee employee = employeeDao.get(id);
        model.addAttribute("emp",employee);
        Collection<Department> departments=departmentDao.getDepartments();
        model.addAttribute("depts",departments);
        return "emp/edit";
    }
    //员工修改
    @PutMapping("/emp")
    public String updateEmployee(Employee employee){
        employeeDao.save(employee);
        return "redirect:/emps";
    }
    //员工删除
    @PostMapping("/emp/{id}")
    public String deleteEmp(@PathVariable("id")Integer id){
        employeeDao.delete(id);
        return "redirect:/emps";
    }
}
