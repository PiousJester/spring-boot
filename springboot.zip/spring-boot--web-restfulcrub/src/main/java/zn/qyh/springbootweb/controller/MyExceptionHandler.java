package zn.qyh.springbootweb.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import zn.qyh.springbootweb.exception.UserNotExist;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 曲逸涵
 * @date 2020/3/23 18:30
 * @Email:2628908921@qq.com
 */
@ControllerAdvice
public class MyExceptionHandler {
//     浏览器返回的都是json数据
//    @ResponseBody
//    @ExceptionHandler(UserNotExist.class)
//    public Map<String, Object> handleException(Exception e){
//        Map<String,Object> map= new HashMap<>();
//        map.put("code","user.notexist");
//        map.put("message",e.getMessage());
//        return map;
//    }
    @ExceptionHandler(UserNotExist.class)
    public String  handleException(Exception e, HttpServletRequest request){
        Map<String,Object> map= new HashMap<>();
        //传入错误状态码
        request.setAttribute("javax.servlet.error.status_code",500);
        map.put("code","user.notexist");
        map.put("message",e.getMessage());
        request.setAttribute("ext",map);
        return "forward:/error";
    }
}
