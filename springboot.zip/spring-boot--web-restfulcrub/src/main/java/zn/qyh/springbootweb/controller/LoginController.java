package zn.qyh.springbootweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Locale;
import java.util.Map;

import static org.springframework.util.StringUtils.*;

/**
 * @author 曲逸涵
 * @date 2020/3/16 14:42
 * @Email:2628908921@qq.com
 */
@Controller
public class LoginController {
    @PostMapping(value = "/user/login")
    //@RequestMapping(value = "/user/login",method= RequestMethod.POST)
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        Map<String,Object> map, HttpSession session) {
        if(!isEmpty(username) && "123456".equals(password)) {
            //登陆成功,防止表单重复提交,可以重定向到主页
            session.setAttribute("loginUser",username);
            return "redirect:/main.html";
        }else {
            //登陆失败
            map.put("msg","登录错误");
            return "login";
        }
    }
}
