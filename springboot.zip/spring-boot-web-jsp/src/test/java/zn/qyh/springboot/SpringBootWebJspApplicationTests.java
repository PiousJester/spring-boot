package zn.qyh.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebJspApplicationTests {

    @Test
    void contextLoads() {
    }

}
