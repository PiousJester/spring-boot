package zn.qyh.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebJspApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebJspApplication.class, args);
    }

}
