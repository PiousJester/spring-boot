package zn.qyh.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author 曲逸涵
 * @date 2020/3/26 16:45
 * @Email:2628908921@qq.com
 */
@Controller
public class HelloController {
    @GetMapping("/abc")
    public String hello(Model model){
       model.addAttribute("msg","你好");
        return "/WEB-INF/success.jsp";
    }
}
